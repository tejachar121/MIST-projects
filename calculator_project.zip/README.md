# Simple Calculator (Python Tkinter)

A basic GUI calculator app built with Python's Tkinter library.

## Features
- Add, Subtract, Multiply, Divide
- Clear and Evaluate input
- Real-time result display
- Simple and clean interface

## How to Run
1. Make sure Python is installed.
2. Run the calculator using:
```bash
python calculator.py
```

## Requirements
- Python 3.x (no external libraries required)
